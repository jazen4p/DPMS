<html>
    <a href="<?php echo base_url()?>Dashboard/add_input_bast">generate</a>
</html>