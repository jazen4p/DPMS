
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">