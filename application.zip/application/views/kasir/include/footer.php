
  <footer class="main-footer" style="background-color: lightblue; color: black">
    <div class="float-right d-none d-sm-block">
      <b>Coded by</b> <a href="https://www.instagram.com/jazen4p/">Jasen Aprian Putra</a> For <a href="http://msgroup.co.id/">MS Group</a>
    </div>
    <strong>Copyright &copy; 2020 MS Group.</strong> All rights
    reserved.
  </footer>